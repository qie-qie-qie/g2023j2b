from pathlib import Path
import re
p=Path(__file__).parent
s=(p/'original.html').read_text().split('<script>')[1].split('</script>')[0]
def function(name, body):
 global s
 pattern=r'  (?:async )?function '+name+r'\([^\n]*\) \{.*?\n  \}'
 s,n=re.subn(pattern,lambda _:body,s,count=1,flags=re.S)
 assert n, name
s=s.replace('localStorage.', 'storage.')
s=s.replace('  const W =', '''  const storage = { getItem(k) { try { return localStorage.getItem(k); } catch { return null; } }, setItem(k,v) { try { localStorage.setItem(k,v); } catch { storageFailed = true; } }, removeItem(k) { try { localStorage.removeItem(k); } catch {} } };
  let storageFailed = false;
  const SAVE_KEY = "class-merge-progress-v2", BEST_KEY = "class-merge-best-v2";
  let guest = true, paused = false, modalWasRunning = false, highest = 0, cooldown = 0, saveClock = 0;
  let combo = 0, lastMerge = -10, audioContext = null, soundOn = storage.getItem("class-merge-sound") === "1";
  const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const W =''')
s=s.replace('color: "#8ecae6"','color: "#b7d4b4"').replace('color: "#90be6d"','color: "#f1d68b"').replace('color: "#f9c74f"','color: "#eeb48d"').replace('color: "#f8961e"','color: "#d9b3b2"').replace('color: "#ef476f"','color: "#b4c8db"').replace('color: "#b5838d"','color: "#c2b8d6"').replace('color: "#7b2cbf"','color: "#b8cb86"').replace('color: "#00b4d8"','color: "#8ebfae"').replace('color: "#ffb703"','color: "#e5bd67"')
s=s.replace('const scale = 2;', 'const scale = Math.min(2.5, Math.max(1, window.devicePixelRatio || 1));')
s=s.replace('const W = 480, H = 720;', 'const W = 480; let H = 720;')
s=s.replace('const LEFT = 18, RIGHT = W - 18, FLOOR = H - 22;', 'const LEFT = 18, RIGHT = W - 18; let FLOOR = H - 22;')
s=s.replace('    const scale = Math.min', '''    const bounds = canvas.getBoundingClientRect();
    const oldFloor = FLOOR;
    H = bounds.width > 0 ? W*bounds.height/bounds.width : 720;
    FLOOR = H-22;
    if (oldFloor !== FLOOR) for (const b of state.balls) { b.y = FLOOR-(oldFloor-b.y); clampBallToWorld(b); }
    const scale = Math.min''')
s=s.replace('    state.balls = [];\n    state.pops = [];\n    state.messages = [];\n    state.fireworks = [];\n    state.score = 0;', '    highest = 0; cooldown = 0; combo = 0; lastMerge = -10; paused = false;\n    document.getElementById("pauseOverlay").hidden = true;\n    state.balls = [];\n    state.pops = [];\n    state.messages = [];\n    state.fireworks = [];\n    state.score = 0;',1)
s=s.replace('    configureCanvasQuality();\n  }','    configureCanvasQuality();\n    saveProgress();\n  }',1)
s=s.replace('    const spec = TIERS[state.next];','    updateExtraHud();\n    const spec = TIERS[state.next];',1)
function('drop', '''  function drop() {
    if (!state.running || !state.loggedIn || !state.canDrop) return;
    unlockAudio();
    const r = TIERS[state.current].radius;
    const x = Math.min(RIGHT-r, Math.max(LEFT+r, state.aimX));
    spawnBall(state.current, x, DROP_Y);
    highest = Math.max(highest, state.current);
    state.current = state.next; state.next = randomTier();
    state.canDrop = false; cooldown = .33;
    tone(190, .06, .025); syncHud(); saveProgress();
  }''')
s=s.replace('    state.score += TIERS[a.tier].score + spec.score;', '''    combo = state.elapsed-lastMerge < 1.2 ? combo+1 : 1;
    lastMerge = state.elapsed;
    state.score += TIERS[a.tier].score + spec.score;
    highest = Math.max(highest, a.tier+1);
    storage.setItem(BEST_KEY, String(Math.max(Number(storage.getItem(BEST_KEY)) || 0, state.score)));
    tone(280 * Math.pow(1.19, a.tier), .15, .035);
    if (combo >= 2) showMessage(`${combo} 连合 · 默契满分！`, 1.1);''')
s=s.replace('tier: a.tier + 1, x, y, vx: 0, vy: 0,','tier: a.tier + 1, x, y, vx: (a.vx+b.vx)*.25, vy: Math.min(0,(a.vy+b.vy)*.2),')
s=s.replace('const dx=b.x-a.x, dy=b.y-a.y;', 'const dx=b.x-a.x || (b.y===a.y ? .001 : 0), dy=b.y-a.y;')
s=s.replace('const restitution=0.72;', 'const restitution=0.12;')
s=s.replace('    const response = await fetch', '    const response = await fetch')
s=s.replace('      method: "POST",','      method: "POST",\n      signal: AbortSignal.timeout(8000),')
s=s.replace('    });\n    const text = await response.text();', '''    }).catch(error => { throw new Error(error.name === "TimeoutError" ? "班级服务响应超时，请稍后重试。" : "暂时连接不上班级服务，请检查网络后重试。本地试玩不受影响。"); });
    const text = await response.text();''')
function('showLogin', '''  function showLogin(message="") {
    loginMessage.textContent = message;
    openModal(loginOverlay);
    usernameInput.focus();
  }''')
s=s.replace('    loginMessage.textContent = "";','    loginMessage.textContent = "";',1)
s=s.replace('      loginOverlay.hidden = true;\n      reset();','      loginOverlay.close();\n      modalWasRunning = false;\n      guest = false;\n      reset();\n      toast("已登录班级账号，新一局开始");')
s=s.replace('  function applySession(session) {\n    if (!session)', '  function applySession(session) {\n    guest = false;\n    if (!session)')
function('restoreSession', '''  async function restoreSession() {
    state.loggedIn = true;
    state.best = Number(storage.getItem(BEST_KEY)) || 0;
    let restored = false;
    try {
      const saved = JSON.parse(storage.getItem(SAVE_KEY));
      if (saved && saved.version === 2 && Array.isArray(saved.balls) && saved.balls.length <= 250 &&
          [saved.current,saved.next].every(t=>Number.isInteger(t)&&t>=0&&t<4) &&
          Number.isFinite(saved.score) && saved.score >= 0 && Number.isFinite(saved.elapsed) &&
          Number.isFinite(saved.highest) && saved.highest >= 0 && saved.highest < TIERS.length &&
          saved.balls.every(b=>Number.isInteger(b.tier)&&b.tier>=0&&b.tier<TIERS.length&&
            [b.x,b.y,b.vx,b.vy,b.age].every(Number.isFinite)&&b.age>=0)) {
        Object.assign(state, { balls:saved.balls.map(b=>({...b,r:TIERS[b.tier].radius})),
          current:saved.current,next:saved.next,score:saved.score,elapsed:saved.elapsed,running:true,canDrop:true });
        state.balls.forEach(clampBallToWorld); highest = saved.highest; restored = true;
        syncHud(); toast("上次的相遇，继续啦");
      }
    } catch { storage.removeItem(SAVE_KEY); }
    if (!restored) reset();
    const token = storage.getItem(SESSION_STORAGE_KEY);
    if (token) {
      document.getElementById("gameStatus").textContent = "正在恢复班级登录…";
      try {
        const session = await supabaseRpc("game_session", { p_token:token });
        // Keep the recovered board; only switch identity after validation.
        applySession(session);
      } catch { storage.removeItem(SESSION_STORAGE_KEY); toast("班级连接暂不可用，已进入本地试玩"); }
      syncHud();
    }
  }''')
s=s.replace('    if (!state.sessionToken) return;', '    if (guest || !state.sessionToken) return;',1)
s=s.replace('    boardOverlay.hidden = false;', '    openModal(boardOverlay);')
function('handleLogout', '''  async function handleLogout() {
    const token = state.sessionToken;
    storage.removeItem(SESSION_STORAGE_KEY);
    state.sessionToken = null; state.username = null; guest = true;
    state.best = Number(storage.getItem(BEST_KEY)) || 0;
    loginOverlay.close(); modalWasRunning = false;
    reset(); toast("已退出账号，进入本地试玩");
    if (token) { try { await supabaseRpc("game_logout",{p_token:token}); } catch {} }
  }''')
function('updateDanger', '''  function updateDanger(dt) {
    let danger = 0;
    for (const b of state.balls) {
      const unsafe = b.age > 1.2 && b.y-b.r < DANGER_Y && Math.abs(b.vy) < 160;
      b.danger = unsafe ? (b.danger||0)+dt : Math.max(0,(b.danger||0)-dt*2);
      danger = Math.max(danger,b.danger);
    }
    state.dangerTime = danger;
    if (danger > 2) {
      state.running = false; finalScore.textContent = String(state.score);
      overlay.hidden = false; storage.removeItem(SAVE_KEY);
      if (!state.scoreSubmitted) { state.scoreSubmitted=true; submitCurrentScore(); }
    }
  }''')
function('drawGuide', '''  function drawGuide() {
    const spec=TIERS[state.current], r=spec.radius;
    const x=Math.min(RIGHT-r,Math.max(LEFT+r,state.aimX));
    let hit=FLOOR-r;
    for (const b of state.balls) {
      const dx=Math.abs(x-b.x), reach=r+b.r;
      if (dx<reach) { const y=b.y-Math.sqrt(reach*reach-dx*dx); if(y>DROP_Y) hit=Math.min(hit,y); }
    }
    ctx.save(); ctx.setLineDash([3,8]); ctx.strokeStyle="#91a38770"; ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(x,DROP_Y+r+8);ctx.lineTo(x,hit);ctx.stroke();ctx.setLineDash([]);
    ctx.globalAlpha=.25;ctx.fillStyle=spec.color;ctx.beginPath();ctx.arc(x,hit,r,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;drawBallShape(x,DROP_Y,r,spec.color,spec.label);ctx.restore();
  }''')
s=s.replace('ctx.strokeStyle="#1e2350"','ctx.strokeStyle="#3c5142"').replace('ctx.fillStyle="#d81159"','ctx.fillStyle="#bb775a"').replace('ctx.strokeStyle="#d81159"','ctx.strokeStyle="#d89c68"')
s=s.replace('ctx.strokeStyle="rgba(30,35,80,.28)"','ctx.strokeStyle="rgba(60,81,66,.10)"')
s=s.replace('return (0.299*r + 0.587*g + 0.114*b) > 165 ? "#172033" : "white";', 'return (0.299*r + 0.587*g + 0.114*b) > 145 ? "#3c5142" : "white";')
function('draw', '''  function draw() {
    ctx.clearRect(0,0,W,H);ctx.fillStyle="#fffef6";ctx.fillRect(0,0,W,H);
    ctx.fillStyle="#a8b99b22";
    for(let x=28;x<W;x+=24)for(let y=140;y<FLOOR;y+=24){ctx.beginPath();ctx.arc(x,y,.9,0,Math.PI*2);ctx.fill();}
    ctx.strokeStyle="#c4cfb6";ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(LEFT,DANGER_Y+10);ctx.lineTo(LEFT,FLOOR);ctx.quadraticCurveTo(LEFT,FLOOR+6,LEFT+8,FLOOR+6);ctx.lineTo(RIGHT-8,FLOOR+6);ctx.quadraticCurveTo(RIGHT,FLOOR+6,RIGHT,FLOOR);ctx.lineTo(RIGHT,DANGER_Y+10);ctx.stroke();
    ctx.strokeStyle=state.dangerTime>.1?"#d47c65":"#d8ab9399";ctx.setLineDash([5,7]);ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(LEFT+9,DANGER_Y);ctx.lineTo(RIGHT-9,DANGER_Y);ctx.stroke();ctx.setLineDash([]);
    ctx.fillStyle="#b99a84";ctx.font="10px system-ui";ctx.textAlign="left";
    ctx.fillText(state.dangerTime>.1 ? `即将堆满 · ${(Math.max(0,2-state.dangerTime)).toFixed(1)}s` : "小心这条线哦",LEFT+8,DANGER_Y-12);
    if(state.dangerTime>.1){ctx.fillStyle=`rgba(214,120,95,${Math.min(.15,state.dangerTime*.07)})`;ctx.fillRect(LEFT,DANGER_Y,RIGHT-LEFT,50);}
    if(state.running&&state.canDrop)drawGuide();
    for(const b of state.balls)drawBallShape(b.x,b.y,b.r,TIERS[b.tier].color,TIERS[b.tier].label);
    if(!reducedMotion)for(const p of state.pops)drawSynthesisPop(p);
    drawCelebrations();
  }''')
start=s.index('  let last=performance.now();');end=s.index('\n  function pointerX',start)
s=s[:start]+'''  let last=performance.now(), accumulator=0;
  function frame(now) {
    const dt=Math.min(.1,Math.max(0,(now-last)/1000));last=now;
    if(state.running) {
      accumulator+=dt;
      while(accumulator>=1/120) {
        const step=1/120;state.elapsed+=step;cooldown=Math.max(0,cooldown-step);state.canDrop=cooldown===0;
        physics(step);updateDanger(step);updatePops(step);updateCelebrations(step);accumulator-=step;
        if(!state.running){accumulator=0;break;}
      }
      saveClock+=dt;if(saveClock>1){saveClock=0;saveProgress();}
    } else accumulator=0;
    draw();requestAnimationFrame(frame);
  }
''' + s[end:]
s=s.replace('    if (aimingPointerId !== null && event.pointerId !== aimingPointerId) return;', '    if (aimingPointerId !== null && event.pointerId !== aimingPointerId) return;')
s=s.replace('    aimingPointerId = event.pointerId;', '    if (!state.running || aimingPointerId !== null) return;\n    aimingPointerId = event.pointerId;\n    canvas.focus({preventScroll:true});')
s=s.replace('  boardClose.addEventListener("click", () => { boardOverlay.hidden = true; });','  boardClose.addEventListener("click", () => boardOverlay.close());')
s=s.replace('if (event.target === boardOverlay) boardOverlay.hidden = true;', 'if (event.target === boardOverlay) boardOverlay.close();')
s=s.replace('    if (!state.running || !loginOverlay.hidden) return;', '''    if (["INPUT","TEXTAREA","BUTTON"].includes(event.target.tagName) || document.querySelector("dialog[open]")) return;
    if(event.key.toLowerCase()==="p"){togglePause();event.preventDefault();return;}
    if (!state.running) return;''')
s=s.replace('if (event.key === "ArrowDown" || event.key === " ") { drop();', 'if ((event.key === "ArrowDown" || event.key === " ") && !event.repeat) { drop();')
s=s.replace('state.aimX -= 20;', 'state.aimX = Math.max(LEFT+TIERS[state.current].radius,state.aimX-20);').replace('state.aimX += 20;', 'state.aimX = Math.min(RIGHT-TIERS[state.current].radius,state.aimX+20);')
s=s.replace('document.getElementById("restart").addEventListener("click", reset);','document.getElementById("restart").addEventListener("click", () => openModal(document.getElementById("confirmDialog")));')
extra='''
  function updateExtraHud() {
    document.getElementById("emptyHint").hidden = state.balls.length>0 || !overlay.hidden;
    document.getElementById("gameStatus").textContent = storageFailed ? "本地存储不可用 · 进度未保存" : (guest ? "● 本地试玩 · 自动保存" : `● ${state.username} · 班级账号`);
    document.getElementById("account").textContent = guest ? "登录班级账号 ↗" : `${state.username} · 管理账号 ↗`;
    logoutButton.hidden=guest;loginForm.hidden=!guest;
    document.getElementById("discovered").textContent=`${highest+1} / 9`;
    document.getElementById("progressFill").style.width=`${(highest+1)/9*100}%`;
    document.getElementById("tierList").replaceChildren(...TIERS.map((t,i)=>{
      const row=document.createElement("div");row.className=`tier-row ${i>highest?'locked':''} ${i===8?'final':''}`;
      const badge=document.createElement("span");badge.className="tier-badge";badge.style.background=t.color;
      if(tierImages[t.label]) {const img=document.createElement("img");img.src=tierImages[t.label].src;img.alt=t.label;badge.append(img);}else badge.textContent=t.label;
      const name=document.createElement("span");name.className="tier-name";name.textContent=t.label;
      const level=document.createElement("span");level.className="tier-level";level.textContent=`Lv.0${i+1}`;
      row.append(badge,name,level);return row;
    }));
    const sound=document.getElementById("sound");sound.setAttribute("aria-pressed",String(soundOn));sound.title=soundOn?"关闭音效":"开启音效";sound.setAttribute("aria-label",sound.title);sound.style.opacity=soundOn?'1':'.5';
  }
  function saveProgress() {
    if(overlay.hidden && state.loggedIn) storage.setItem(SAVE_KEY,JSON.stringify({version:2,balls:state.balls,current:state.current,next:state.next,score:state.score,elapsed:state.elapsed,highest}));
  }
  function unlockAudio() {
    if(!soundOn)return;
    try { const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;audioContext ||= new Audio(); if(audioContext.state==='suspended')audioContext.resume().catch(()=>{}); } catch {}
  }
  function tone(hz,duration,volume) {
    if(!soundOn||!audioContext)return;
    const osc=audioContext.createOscillator(),gain=audioContext.createGain();osc.type='sine';osc.frequency.setValueAtTime(hz,audioContext.currentTime);osc.frequency.exponentialRampToValueAtTime(hz*.7,audioContext.currentTime+duration);gain.gain.setValueAtTime(volume,audioContext.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+duration);osc.connect(gain).connect(audioContext.destination);osc.start();osc.stop(audioContext.currentTime+duration);
  }
  function toast(text) {const t=document.getElementById("toast");t.textContent=text;t.classList.add("visible");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("visible"),3000);}
  function openModal(dialog) {
    if(document.querySelector("dialog[open]"))return;
    modalWasRunning=state.running;state.running=false;aimingPointerId=null;saveProgress();dialog.showModal();
  }
  function togglePause() {
    if(!overlay.hidden||document.querySelector("dialog[open]"))return;
    paused=!paused;state.running=!paused;aimingPointerId=null;
    document.getElementById("pauseOverlay").hidden=!paused;
    document.getElementById("pause").textContent=paused?'▶':'Ⅱ';
    document.getElementById("pause").setAttribute('aria-label',paused?'继续':'暂停');saveProgress();
  }
  for(const d of document.querySelectorAll("dialog"))d.addEventListener("close",()=>{if(modalWasRunning&&!paused&&overlay.hidden)state.running=true;modalWasRunning=false;last=performance.now();});
  for(const b of document.querySelectorAll("[data-close]"))b.addEventListener("click",()=>b.closest("dialog").close());
  document.getElementById("help").addEventListener("click",()=>openModal(document.getElementById("helpDialog")));
  document.getElementById("account").addEventListener("click",()=>showLogin());
  document.getElementById("pause").addEventListener("click",togglePause);
  document.getElementById("resume").addEventListener("click",togglePause);
  document.getElementById("confirmRestart").addEventListener("click",()=>{document.getElementById("confirmDialog").close();reset();toast("新的相遇，开始！");});
  document.getElementById("sound").addEventListener("click",()=>{soundOn=!soundOn;storage.setItem("class-merge-sound",soundOn?'1':'0');unlockAudio();tone(440,.13,.04);updateExtraHud();});
  document.addEventListener("visibilitychange",()=>{if(document.hidden&&state.running)togglePause();saveProgress();});
  window.addEventListener("pagehide",saveProgress);
  window.addEventListener("resize",configureCanvasQuality);
  // Available only to the local deterministic regression suite, never on hosted URLs.
  if(location.hostname==='localhost' && new URLSearchParams(location.search).has('test'))window.__gameTest={state,physics,updateDanger,drop,reset,mergeBalls,TIERS,togglePause,saveProgress,get highest(){return highest;}};
'''
s=s.replace('  configureCanvasQuality();\n  syncHud();',extra+'\n  configureCanvasQuality();\n  syncHud();')
(p/'dist/game.js').write_text(s)
print('Game generated:',len(s),'characters')
